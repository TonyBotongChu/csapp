#include <stdio.h>
int main()
{
	printf("Hello Zhu Botong!");
	return 0;
} 
